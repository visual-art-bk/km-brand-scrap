"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const handler = async () => {
    const response = {
        statusCode: 200,
        body: JSON.stringify("하이 병관!"),
    };
    return response;
};
exports.handler = handler;
